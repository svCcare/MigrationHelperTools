﻿namespace $rootnamespace$
{
    using FluentMigrator;

    [Migration(TIMESTAMP)]
    public class MTIMESTAMP_NAME : Migration
    {
        public override void Up()
        {
            
        }

        public override void Down()
        {
            
        }
    }
}
